# نظام إسلام خالد ERP - مشروع Android Studio

تطبيق Android أصلي (APK) يحوي نظام إدارة المقاولات كاملاً.

## المميزات
- ✅ WebView أصلي يحوي نظام ERP كامل
- ✅ يعمل بدون إنترنت (بعد أول تشغيل)
- ✅ البيانات تُحفظ في الذاكرة الداخلية للجوال (`/data/data/com.islamkhaled.erp/`)
- ✅ localStorage + IndexedDB (تخزين مزدوج)
- ✅ سحب للتحديث (Pull to Refresh)
- ✅ اختيار الملفات من المعرض (رفع صور العمال/العملاء)
- ✅ زر الرجوع يعمل داخل التطبيق
- ✅ شريط تقدم أثناء التحميل
- ✅ إعدادات Android كاملة (minSdk 21، targetSdk 34)
- ✅ دعم RTL كامل
- ✅ أيقونة تكيفية (Adaptive Icon) مع Theme Color

## طريقة البناء

### الخيار 1: من Android Studio
1. افتح Android Studio (الحد الأدنى Hedgehog | 2023.1.1)
2. **File → Open** → اختر مجلد `erp-androidstudio`
3. انتظر Gradle Sync (~2-3 دقائق لتحميل التبعيات)
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. الـ APK في: `app/build/outputs/apk/debug/app-debug.apk`

### الخيار 2: من سطر الأوامر
```bash
cd erp-androidstudio
./gradlew assembleDebug      # APK debug
./gradlew assembleRelease    # APK release (بـ debug signing)
```
الـ APK ينولد في `app/build/outputs/apk/`

## التثبيت على الجوال
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```
أو انسخ الـ APK على الجوال وافتحه (مع تفعيل "تثبيت من مصادر غير معروفة").

## التوقيع للنشر على Google Play
1. في Android Studio: **Build → Generate Signed Bundle / APK**
2. اختر **Android App Bundle** و **release**
3. أنشئ keystore جديد أو استخدم موجود
4. اتبع المعالج → يولد `.aab` جاهز للرفع

## موقع التخزين الداخلي للبيانات
- App data: `/data/data/com.islamkhaled.erp/`
- WebView Storage: `/data/data/com.islamkhaled.erp/app_webview/`
- localStorage: داخل مجلد WebView
- IndexedDB: `app_webview/Default/IndexedDB/`

كل البيانات تبقى في الجوال ولا تغادره (Offline-first).

## معلومات تقنية
- **Package**: com.islamkhaled.erp
- **Version**: 2026.1.1 (versionCode 1)
- **minSdk**: 21 (Android 5.0 Lollipop)
- **targetSdk**: 34 (Android 14)
- **Kotlin**: 1.9.22
- **Gradle**: 8.4
- **AGP**: 8.2.2

## المطور
إسلام خالد حسان — 776543059 — islamalmoliky@Gmail.com
