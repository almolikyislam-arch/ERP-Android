package com.islamkhaled.erp

import android.app.Application
import android.content.Context
import android.webkit.WebView

class ERPApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // تفعيل تخزين DOM في WebView (لازم)
        try {
            val chromiumPath = WebView.getCurrentWebViewPackage()?.packageName
            // فتح مجلد الـ webview data بشكل آمن
        } catch (_: Exception) {}
    }
}
