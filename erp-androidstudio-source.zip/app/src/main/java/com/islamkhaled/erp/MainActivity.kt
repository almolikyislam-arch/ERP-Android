package com.islamkhaled.erp

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.islamkhaled.erp.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var uploadMessage: ValueCallback<Uri>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            filePathCallback?.onReceiveValue(arrayOf(uri))
            uploadMessage?.onReceiveValue(uri)
        } else {
            filePathCallback?.onReceiveValue(null)
            uploadMessage?.onReceiveValue(null)
        }
        filePathCallback = null
        uploadMessage = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // وضع ملء الشاشة
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // === إعدادات WebView ===
        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true              // localStorage
            databaseEnabled = true                // IndexedDB
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            // لغة افتراضية
            @Suppress("DEPRECATION")
            defaultTextEncodingName = "UTF-8"

            // مسار التخزين الداخلي للتطبيق
            databaseEnabled = true
        }

        // === WebView Client (داخل التطبيق) ===
        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE
            }
        }

        // === Chrome Client (لاختيار الملفات) ===
        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress < 100) {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.progressBar.progress = newProgress
                } else {
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.filePathCallback = filePathCallback
                try {
                    fileChooserLauncher.launch("image/*")
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "خطأ في اختيار الملف", Toast.LENGTH_SHORT).show()
                    return false
                }
                return true
            }
        }

        // === Service Worker (للعمل بدون نت) ===
        binding.webView.setOnLongClickListener { true }

        // === تحميل التطبيق ===
        binding.webView.loadUrl("file:///android_asset/index.html")

        // === السحب للتحديث ===
        binding.swipeRefresh.setOnRefreshListener {
            binding.webView.reload()
        }

        // === مراقبة حالة الشبكة ===
        binding.webView.evaluateJavascript("""
            (function(){
                window.addEventListener('online', function(){
                    console.log('online');
                });
                window.addEventListener('offline', function(){
                    console.log('offline');
                });
            })();
        """.trimIndent(), null)
    }

    // === دعم زر الرجوع ===
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && binding.webView.canGoBack()) {
            binding.webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        binding.webView.restoreState(savedInstanceState)
    }
}
